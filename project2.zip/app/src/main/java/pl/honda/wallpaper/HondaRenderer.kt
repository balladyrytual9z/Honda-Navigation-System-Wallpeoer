package pl.honda.wallpaper

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Calendar
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class HondaRenderer(private val ctx: Context) : GLSurfaceView.Renderer {

    private var program = 0
    private var texImage = 0
    private var texNoise = 0
    private var imgW = 1280
    private var imgH = 720
    private var surfW = 1
    private var surfH = 1
    private val startMs = SystemClock.elapsedRealtime()

    private val quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
        }

    private var uTex = 0; private var uNoise = 0; private var uTexel = 0
    private var uCover = 0; private var uFlow = 0; private var uSweep = 0; private var uPulse = 0
    private var uSun = 0; private var uAlt = 0; private var uStar = 0
    private var uLights = 0; private var uMoonTex = 0
    private var uMoonPos = 0; private var uMoonL = 0; private var uMoonIll = 0
    private var texLights = 0; private var texMoon = 0
    private val moonPos = floatArrayOf(0.5f, 0.5f, 0f)
    private val moonL = floatArrayOf(0f, 0f, 1f)
    private var moonIll = 0f
    private var sunX = 0.88f; private var sunY = 0.78f; private var sunAlt = 0f
    private var lastSunMs = -100000L
    private var aPos = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        program = buildProgram(VERTEX, FRAGMENT)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
        uNoise = GLES20.glGetUniformLocation(program, "uNoise")
        uTexel = GLES20.glGetUniformLocation(program, "uTexel")
        uCover = GLES20.glGetUniformLocation(program, "uCover")
        uFlow = GLES20.glGetUniformLocation(program, "uFlow")
        uSweep = GLES20.glGetUniformLocation(program, "uSweep")
        uPulse = GLES20.glGetUniformLocation(program, "uPulse")
        uSun = GLES20.glGetUniformLocation(program, "uSun")
        uAlt = GLES20.glGetUniformLocation(program, "uAlt")
        uStar = GLES20.glGetUniformLocation(program, "uStar")
        uLights = GLES20.glGetUniformLocation(program, "uLights")
        uMoonTex = GLES20.glGetUniformLocation(program, "uMoonTex")
        uMoonPos = GLES20.glGetUniformLocation(program, "uMoonPos")
        uMoonL = GLES20.glGetUniformLocation(program, "uMoonL")
        uMoonIll = GLES20.glGetUniformLocation(program, "uMoonIll")
        loadImage()
        makeNoise()
        texLights = loadSimple(R.drawable.city_lights)
        texMoon = loadSimple(R.drawable.moon_tex)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfW = maxOf(width, 1); surfH = maxOf(height, 1)
        GLES20.glViewport(0, 0, surfW, surfH)
    }

    override fun onDrawFrame(gl: GL10?) {
        val t = (SystemClock.elapsedRealtime() - startMs) / 1000f

        // przycięcie obrazka tak, żeby wypełniał ekran (jak "cover")
        val sa = surfW.toFloat() / surfH
        val ia = imgW.toFloat() / imgH
        val cx = if (sa > ia) 1f else sa / ia
        val cy = if (sa > ia) ia / sa else 1f

        val flowA = (t / 420f) % 1f          // powolny dryf chmur (zapętla się bez skoku)
        val flowB = (t / 700f) % 1f          // jeszcze wolniejsze "falowanie" chmur
        val sweep = (t % 11f) / 5f           // 0..1 = przejście błysku, dalej przerwa
        val pulse = 0.5f + 0.5f * Math.sin(2.0 * Math.PI * (t % 9f) / 9f).toFloat()

        val star = (2.0 * Math.PI * ((t % 9f) / 9f)).toFloat()   // migotanie gwiazd
        updateSun()

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImage)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texNoise)
        GLES20.glUniform1i(uNoise, 1)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texLights)
        GLES20.glUniform1i(uLights, 2)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE3)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texMoon)
        GLES20.glUniform1i(uMoonTex, 3)

        GLES20.glUniform2f(uTexel, 1f / imgW, 1f / imgH)
        GLES20.glUniform2f(uCover, cx, cy)
        GLES20.glUniform2f(uFlow, flowA, flowB)
        GLES20.glUniform1f(uSweep, sweep)
        GLES20.glUniform1f(uPulse, pulse)
        GLES20.glUniform2f(uSun, sunX, sunY)
        GLES20.glUniform1f(uAlt, sunAlt)
        GLES20.glUniform1f(uStar, star)
        GLES20.glUniform3f(uMoonPos, moonPos[0], moonPos[1], moonPos[2])
        GLES20.glUniform3f(uMoonL, moonL[0], moonL[1], moonL[2])
        GLES20.glUniform1f(uMoonIll, moonIll)

        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
    }


    /**
     * Słońce według prawdziwego zegara telefonu (okolice środka Polski, 52°N 19°E).
     * Wschód = prawa krawędź Ziemi, zachód = lewa. W nocy chowa się za Ziemią.
     */
    private fun updateSun() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastSunMs < 2000) return
        lastSunMs = now

        val cal = Calendar.getInstance()
        val tz = cal.timeZone.getOffset(cal.timeInMillis) / 3600000.0
        val hour = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0 +
            cal.get(Calendar.SECOND) / 3600.0
        val n = cal.get(Calendar.DAY_OF_YEAR)

        val lat = Math.toRadians(52.0)
        val lon = 19.0
        val decl = Math.toRadians(23.44) * Math.sin(2.0 * Math.PI * (n - 81) / 365.0)
        val c = (-Math.tan(lat) * Math.tan(decl)).coerceIn(-1.0, 1.0)
        val half = (Math.acos(c) * 12.0 / Math.PI).coerceIn(2.0, 10.0)  // pół dnia w godzinach
        val noon = 12.0 + (15.0 * tz - lon) / 15.0

        var h = hour - noon
        while (h > 12.0) h -= 24.0
        while (h < -12.0) h += 24.0

        val alt = if (Math.abs(h) <= half) {
            Math.cos(Math.PI / 2.0 * h / half)
        } else {
            val nightHalf = 12.0 - half
            -Math.sin(Math.PI / 2.0 * (Math.abs(h) - half) / nightHalf)
        }

        val pc = (h / half).coerceIn(-1.3, 1.3)
        val x = 0.5 - 0.38 * Math.sin(Math.PI / 2.0 * pc)
        val yh = 0.708 + 0.769 * (x - 0.484) * (x - 0.484) - 0.05 * x
        val y = yh - 0.28 * alt

        sunX = x.toFloat(); sunY = y.toFloat(); sunAlt = alt.toFloat()

        // --- Księżyc: faza z prawdziwej daty (wzory Meeusa, uproszczone) ---
        val jd = System.currentTimeMillis() / 86400000.0 + 2440587.5
        val tc = (jd - 2451545.0) / 36525.0
        val dd = 297.8501921 + 445267.1114034 * tc
        val mm = 357.5291092 + 35999.0502909 * tc
        val mp = 134.9633964 + 477198.8675055 * tc
        fun sd(a: Double) = Math.sin(Math.toRadians(a))
        val inc = 180.0 - dd - 6.289 * sd(mp) + 2.100 * sd(mm) - 1.274 * sd(2 * dd - mp) -
            0.658 * sd(2 * dd) - 0.214 * sd(2 * mp) - 0.110 * sd(dd)
        var psi = 180.0 - inc                        // elongacja: 0 = nów, 180 = pełnia
        psi = ((psi % 360.0) + 360.0) % 360.0
        val psiR = Math.toRadians(psi)
        moonIll = ((1.0 - Math.cos(psiR)) / 2.0).toFloat()

        // Księżyc przechodzi przez południk ok. psi/15 godz. po Słońcu
        var hm = h - psi / 15.0
        while (hm > 12.0) hm -= 24.0
        while (hm < -12.0) hm += 24.0
        val halfM = 6.0
        val altM = if (Math.abs(hm) <= halfM) Math.cos(Math.PI / 2.0 * hm / halfM)
                   else -Math.sin(Math.PI / 2.0 * (Math.abs(hm) - halfM) / (12.0 - halfM))
        val pcm = (hm / halfM).coerceIn(-1.3, 1.3)
        val mx = 0.5 - 0.38 * Math.sin(Math.PI / 2.0 * pcm)
        val myh = 0.708 + 0.769 * (mx - 0.484) * (mx - 0.484) - 0.05 * mx
        val my = myh - 0.30 * altM

        // widoczny tylko w nocy i nad horyzontem
        val night = 1.0 - smooth(-0.02, 0.15, alt)
        val up = smooth(-0.05, 0.10, altM)
        moonPos[0] = mx.toFloat(); moonPos[1] = my.toFloat(); moonPos[2] = (night * up).toFloat()

        // kierunek światła na tarczy: przybywa = oświetlona lewa strona (zachód), ubywa = prawa
        val side = if (psi < 180.0) -1.0 else 1.0
        val dl = Math.hypot(side, 0.45)
        val sn = Math.abs(Math.sin(psiR))
        moonL[0] = (sn * side / dl).toFloat()
        moonL[1] = (sn * 0.45 / dl).toFloat()
        moonL[2] = (-Math.cos(psiR)).toFloat()
    }

    private fun smooth(a: Double, b: Double, x: Double): Double {
        val t = ((x - a) / (b - a)).coerceIn(0.0, 1.0)
        return t * t * (3 - 2 * t)
    }

    private fun loadSimple(res: Int): Int {
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val bmp = BitmapFactory.decodeResource(ctx.resources, res, opts)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
        return ids[0]
    }

    private fun loadImage() {
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.wallpaper_base, opts)
        imgW = bmp.width; imgH = bmp.height
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texImage = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImage)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
    }

    /** Mała tekstura losowego szumu (64x64) - z niej powstają chmury. */
    private fun makeNoise() {
        val n = 64
        val data = ByteArray(n * n * 4)
        Random(7).nextBytes(data)
        val buf = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
        buf.put(data); buf.position(0)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texNoise = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texNoise)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, n, n, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader error: $log")
        }
        return s
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val VERTEX = """
attribute vec2 aPos;
uniform vec2 uCover;
varying vec2 vUv;
void main() {
    vec2 uv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
    vUv = (uv - 0.5) * uCover + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

        private const val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform sampler2D uTex;
uniform sampler2D uNoise;
uniform sampler2D uLights;
uniform sampler2D uMoonTex;
uniform vec2 uTexel;
uniform vec2 uFlow;
uniform vec2 uSun;
uniform vec3 uMoonPos;   // x, y (uv), widoczność 0..1
uniform vec3 uMoonL;     // kierunek światła na tarczy Księżyca
uniform float uMoonIll;  // oświetlona część tarczy 0..1
uniform float uAlt;
uniform float uSweep;
uniform float uPulse;
uniform float uStar;
varying vec2 vUv;

const float AR = 1.7778;
const float MOON_R = 0.058;

float lumOf(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

float rectMask(vec2 uv, vec2 lo, vec2 hi) {
    vec2 a = smoothstep(lo - 0.01, lo + 0.01, uv);
    vec2 b = 1.0 - smoothstep(hi - 0.01, hi + 0.01, uv);
    return a.x * a.y * b.x * b.y;
}

void main() {
    vec2 uv = vUv;
    vec2 p = vec2(uv.x * AR, uv.y);
    vec2 sunP = vec2(uSun.x * AR, uSun.y);
    vec2 moonP = vec2(uMoonPos.x * AR, uMoonPos.y);
    float mVis = uMoonPos.z;
    float mI = mVis * (0.25 + 0.75 * uMoonIll);        // siła światła księżyca

    float vis = smoothstep(-0.35, 0.05, uAlt);         // czy słońce świeci
    float dayBoost = smoothstep(-0.30, 0.10, uAlt);    // jak mocno oświetlona Ziemia
    float lowW = 1.0 - smoothstep(0.0, 0.55, uAlt);    // niskie słońce = pomarańczowe

    // --- krawędź Ziemi ---
    float yh = 0.708 + 0.769 * (uv.x - 0.484) * (uv.x - 0.484) - 0.05 * uv.x;
    float d = uv.y - yh;
    float earth = smoothstep(0.015, 0.075, d);

    vec3 col;
    if (earth > 0.0) {
        vec2 nc = vec2(p.x * 0.15, pow(max(d, 0.0), 0.6) * 1.35);
        vec2 w = texture2D(uNoise, nc * 0.5 + vec2(uFlow.y, 0.5)).gb - 0.5;
        vec3 n1 = texture2D(uNoise, nc + vec2(uFlow.x, 0.0)).rgb;
        vec3 n2 = texture2D(uNoise, nc * 2.0 + vec2(uFlow.x * 2.0, 0.0) + vec2(0.31, 0.17)).rgb;
        vec3 n3 = texture2D(uNoise, nc * 4.0 + vec2(uFlow.x * 4.0, 0.0) + vec2(0.62, 0.44)).rgb;
        vec3 f = n1 * 0.5 + n2 * 0.3 + n3 * 0.2;

        vec2 disp = (f.gb - 0.5) * 0.014 * earth;
        col = texture2D(uTex, uv + disp).rgb;

        // oświetlenie Ziemi słońcem
        float lightE = clamp(1.0 - abs(p.x - sunP.x) / 1.3, 0.0, 1.0);
        float lightK = lightE * dayBoost;
        float mulE = 0.40 + 0.80 * lightK;
        vec3 tint = mix(vec3(1.0), vec3(1.0, 0.80, 0.62), lowW * lightK);
        col *= mix(1.0, mulE, earth) * mix(vec3(1.0), tint, earth);

        // poświata księżyca na nocnej Ziemi
        float moonNear = exp(-abs(p.x - moonP.x) * 1.1);
        col *= 1.0 + earth * mI * moonNear * 0.9 * vec3(0.55, 0.75, 1.1);

        // chmury
        float c = f.r + w.x * 0.35;
        float cloud = smoothstep(0.50, 0.68, c) * earth;
        float lit = clamp(1.0 - distance(p, sunP) * 0.75, 0.0, 1.0) * dayBoost;
        vec3 cloudNight = vec3(0.10, 0.16, 0.30) + mI * moonNear * vec3(0.16, 0.22, 0.32);
        vec3 cloudCol = mix(cloudNight, mix(vec3(1.0, 0.95, 0.88), vec3(1.0, 0.78, 0.55), lowW), lit * lit);
        col = col * (1.0 - 0.30 * cloud) + cloudCol * cloud * 0.55;

        // światła miast po stronie nocnej (przygaszone przez chmury)
        float nightSide = 1.0 - smoothstep(0.10, 0.50, lightK);
        vec3 lights = texture2D(uLights, uv).rgb;
        col += lights * nightSide * earth * (1.15 * (1.0 - 0.80 * cloud) + 0.25 * cloud);
    } else {
        col = texture2D(uTex, uv).rgb;
    }

    float lum = lumOf(col);
    float region = max(rectMask(uv, vec2(0.385, 0.125), vec2(0.615, 0.46)),
                       rectMask(uv, vec2(0.17, 0.505), vec2(0.82, 0.605)));
    float chrome = region * smoothstep(0.18, 0.40, lum);

    // --- gwiazdy: od czasu do czasu któraś błyska ---
    float sky = 1.0 - smoothstep(-0.02, 0.0, d);
    float starMask = smoothstep(0.10, 0.30, lum) * sky * (1.0 - region);
    if (starMask > 0.0) {
        vec2 cell = floor(uv * vec2(160.0, 90.0));
        vec2 r = texture2D(uNoise, (mod(cell, 64.0) + 0.5) / 64.0).rg;
        float k = 1.0 + floor(r.g * 3.0);
        float tw = pow(0.5 + 0.5 * sin(r.r * 6.2832 + uStar * k), 6.0);
        float fct = 0.55 + 1.6 * tw;
        col = mix(col, col * fct, starMask);
    }

    // --- atmosfera przy krawędzi ---
    float band = exp(-abs(d) * 45.0);
    float warmness = clamp((col.r - col.b) * 3.0, 0.0, 1.0);
    float keep = vis * exp(-abs(p.x - sunP.x) * 2.5);
    vec3 cool = vec3(lum) * vec3(0.80, 0.92, 1.15);
    col = mix(col, cool, warmness * band * (1.0 - keep) * 0.85);
    col += mix(vec3(1.0, 0.78, 0.52), vec3(1.0, 0.40, 0.14), lowW)
         * exp(-abs(d) * 60.0) * exp(-abs(p.x - sunP.x) * 3.0) * vis * 0.45;
    col += vec3(0.55, 0.70, 1.0) * exp(-abs(d) * 60.0) * exp(-abs(p.x - moonP.x) * 3.0) * mI * 0.35;

    // --- słońce (za chromem) ---
    vec2 q = p - sunP;
    float ds = length(q);
    vec3 hot = mix(vec3(1.0, 0.96, 0.86), vec3(1.0, 0.82, 0.48), lowW);
    vec3 warm = mix(vec3(1.0, 0.86, 0.66), vec3(1.0, 0.42, 0.10), lowW);
    float spread = mix(1.0, 0.55, smoothstep(0.3, 1.0, uAlt));
    float disc = 1.0 - smoothstep(0.016, 0.030, ds);
    float flareV = exp(-abs(q.x) * 500.0) * exp(-abs(q.y) * 2.2) * 0.35;
    float flareH = exp(-abs(q.y) * 600.0) * exp(-abs(q.x) * 1.6) * 0.30;
    vec3 glow = hot * (disc * 1.5 + exp(-ds * 18.0) * 0.7)
              + warm * ((exp(-ds * 5.0) * 0.75 + exp(-ds * 1.6) * 0.18) * spread
                        + (flareV + flareH) * (0.85 + 0.15 * uPulse));
    float skyW = 1.0 - smoothstep(-0.006, 0.004, d);   // Ziemia zasłania niebo
    col += glow * skyW * vis * (1.0 - 0.9 * chrome);

    // --- Księżyc z fazą (za chromem) ---
    vec2 mq = (p - moonP) / MOON_R;
    float mr = length(mq);
    if (mVis > 0.0 && mr < 6.0) {
        float kM = skyW * mVis * (1.0 - 0.9 * chrome);
        col += vec3(0.50, 0.62, 0.95)
             * (exp(-mr * 1.6) * 0.10 + exp(-mr * 0.5) * 0.04) * (0.20 + 0.80 * uMoonIll) * kM;
        if (mr < 1.02) {
            float aa = 1.0 - smoothstep(0.96, 1.0, mr);
            vec3 n = vec3(mq, sqrt(max(1.0 - mr * mr, 0.0)));
            vec3 alb = texture2D(uMoonTex, mq * 0.5 + 0.5).rgb;
            float dl = dot(n, uMoonL);
            float nl = clamp(dl, 0.0, 1.0);
            float lam = nl / (nl + n.z + 0.04) * 2.7 * smoothstep(0.0, 0.06, dl);
            vec3 mc = alb * lam * vec3(1.0, 0.98, 0.94)
                    + alb * vec3(0.45, 0.55, 0.85) * 0.045;     // światło popielate
            col = mix(col, mc, aa * kM);
        }
    }

    // --- światło na chromowanym logo i napisie ---
    if (chrome > 0.0) {
        vec2 t2 = uTexel * 2.0;
        float lx1 = lumOf(texture2D(uTex, uv + vec2(t2.x, 0.0)).rgb);
        float lx2 = lumOf(texture2D(uTex, uv - vec2(t2.x, 0.0)).rgb);
        float ly1 = lumOf(texture2D(uTex, uv + vec2(0.0, t2.y)).rgb);
        float ly2 = lumOf(texture2D(uTex, uv - vec2(0.0, t2.y)).rgb);
        vec3 N = normalize(vec3((lx2 - lx1) * 3.0, (ly2 - ly1) * 3.0, 0.6));

        // słońce
        vec3 L = normalize(vec3((sunP - p), 0.30 + 0.25 * uPulse));
        vec3 H = normalize(L + vec3(0.0, 0.0, 1.0));
        float spec = pow(max(dot(N, H), 0.0), 16.0);
        float dif = max(dot(N, L), 0.0);

        float warmL = clamp(1.0 - distance(p, sunP) * 0.8, 0.0, 1.0);
        vec3 lc = mix(vec3(1.0, 0.95, 0.88), vec3(1.0, 0.55, 0.25), max(warmL * 0.6, lowW));

        float s = dot(p, vec2(-0.94, 0.34));
        float pos = mix(-1.55, 0.25, uSweep);
        float x = (s - pos) / 0.07;
        float bnd = exp(-x * x);

        vec3 add = (spec * 0.9 + dif * 0.10 * (0.8 + 0.2 * uPulse)) * lc
                 + bnd * (0.35 + lum) * vec3(1.0, 0.88, 0.70) * 0.85;
        col += chrome * add * vis;
        col += chrome * warmL * lum * 0.18 * vec3(1.0, 0.5, 0.2) * vis;

        // księżyc: zimne, miękkie odbicia (słabsze przy cienkim sierpie)
        if (mVis > 0.0) {
            vec3 Lm = normalize(vec3(moonP - p, 0.35));
            vec3 Hm = normalize(Lm + vec3(0.0, 0.0, 1.0));
            float specM = pow(max(dot(N, Hm), 0.0), 14.0);
            float difM = max(dot(N, Lm), 0.0);
            float xm = (dot(p, vec2(0.94, 0.34)) - mix(-0.4, 1.9, uSweep)) / 0.10;
            float bndM = exp(-xm * xm);
            col += chrome * (specM * 0.85 + difM * 0.09 + bndM * (0.2 + lum) * 0.35)
                 * vec3(0.72, 0.84, 1.0) * mI;
        }

        // nocą od dołu odbija się poświata miast
        col += chrome * lum * 0.10 * vec3(1.0, 0.72, 0.40) * (1.0 - vis) * (0.4 + 0.6 * uv.y);
    }

    gl_FragColor = vec4(col, 1.0);
}
"""
    }
}
